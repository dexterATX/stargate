export { Header } from "./Header";
// Footer removed from layout - will be added back when needed
// export { Footer } from "./Footer";
